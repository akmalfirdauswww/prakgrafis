document.addEventListener("DOMContentLoaded", function () {
    const canvas = document.getElementById("myCanvas");
    const gl = canvas.getContext("webgl");

    if (!gl) {
        console.error("Unable to initialize WebGL. Your browser may not support it.");
        return;
    }

    const vertices = new Float32Array([
        // Titik 1
        0.0, 0.0,
        // Titik 2
        0.2, 0.3,
        // Titik 3
        -0.4, 0.5,
        // Titik 4
        -0.8, -0.2,
        // Titik 5
        0.6, -0.6,
        // Titik 6
        0.4, 0.8,
        // Titik 7
        -0.7, -0.9,
        // Titik 8
        0.9, 0.1,
        // Titik 9
        -0.1, -0.4,
        // Titik 10
        -0.3, 0.7
    ]);

    // Membuat buffer untuk menyimpan data vertices
    const vertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

    // Membuat vertex shader
    const vertCode = `
        attribute vec2 coordinates;
        void main(void) {
            gl_Position = vec4(coordinates, 0.0, 1.0);
            gl_PointSize = 5.0;
        }`;

    const vertShader = gl.createShader(gl.VERTEX_SHADER);
    gl.shaderSource(vertShader, vertCode);
    gl.compileShader(vertShader);

    // Membuat fragment shader
    const fragCode = `
        void main(void) {
            gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
        }`;

    const fragShader = gl.createShader(gl.FRAGMENT_SHADER);
    gl.shaderSource(fragShader, fragCode);
    gl.compileShader(fragShader);

    // Membuat dan menggunakan program shader
    const shaderProgram = gl.createProgram();
    gl.attachShader(shaderProgram, vertShader);
    gl.attachShader(shaderProgram, fragShader);
    gl.linkProgram(shaderProgram);
    gl.useProgram(shaderProgram);

    // Menyambungkan buffer ke atribut 'coordinates'
    const coord = gl.getAttribLocation(shaderProgram, "coordinates");
    gl.vertexAttribPointer(coord, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(coord);

    // Membersihkan canvas dan menggambar titik-titik
    gl.clearColor(1.0, 1.0, 1.0, 1.0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.drawArrays(gl.POINTS, 0, vertices.length / 2);
});